document.getElementById('scan-emails').addEventListener('click', () => {
    console.log("Clicked")
    fetch('http://127.0.0.1:5000/predict', {
      method: 'POST'
    });
});