function extractEmailContent() {
  fetch('http://127.0.0.1:5000/predict', {
    method: 'POST'
  });
  console.log("Content.js Berjalan")
}

window.addEventListener('load', () => {
  console.log('Page loaded, content.js active');
  extractEmailContent();
});

extractEmailContent();