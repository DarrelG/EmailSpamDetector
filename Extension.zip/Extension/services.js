chrome.runtime.onInstalled.addListener(() => {
    console.log("Extension installed and running");
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes("127.0.0.1:5500")) {
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ["content.js"]
        }, () => {
            console.log("Content script injected after page refresh");
        });
    }
});

function PredictEmail(){
    fetch('http://127.0.0.1:5000/predict', {
        method: 'POST'
    });
}

setInterval(PredictEmail, 100);